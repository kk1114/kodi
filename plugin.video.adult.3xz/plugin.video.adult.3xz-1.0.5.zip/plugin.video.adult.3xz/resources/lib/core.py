# -*- coding: UTF-8 -*-
"""
    Add-on Core v0.0.4
    - Core Add-on attributes and methods for Personal Kodi Add-ons
    - Extends t0mm0.common by eldorado

    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import sys
import ast
import re
import urllib
import urllib2
import httplib
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs
from xbmcdict import XBMCDict
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net
from BeautifulSoup import BeautifulSoup
from database import SQLite


class AddonCore(Addon):

    def __init__(self):
        self.handle = int(sys.argv[1])
        self.id = xbmcaddon.Addon().getAddonInfo('id')
        Addon.__init__(self, self.id, sys.argv)
        self.name = xbmcaddon.Addon().getAddonInfo('name')
        self.version = xbmcaddon.Addon().getAddonInfo('version')
        self.author = xbmcaddon.Addon().getAddonInfo('author')
        self.root_path = xbmc.translatePath(os.path.join(xbmc.translatePath('special://home'), 'addons', self.id))
        self.profile_path = xbmc.translatePath(os.path.join(xbmc.translatePath('special://profile'),
                                               'addon_data', self.id))
        if not xbmcvfs.exists(self.profile_path):
            try: xbmcvfs.mkdirs(self.profile_path)
            except: os.mkdir(self.profile_path)
        self.lib_path = xbmc.translatePath(os.path.join(self.root_path, 'resources', 'lib'))
        self.media_path = xbmc.translatePath(os.path.join(self.root_path, 'resources', 'media'))
        self.icon = xbmc.translatePath(os.path.join(self.root_path, 'icon.png'))
        self.fanart = xbmc.translatePath(os.path.join(self.root_path, 'fanart.jpg'))
        self.__cookie_ = xbmc.translatePath(os.path.join(xbmc.translatePath(self.profile_path), 'cookies.txt'))
        if not xbmcvfs.exists(self.__cookie_):
            try:
                __temp_ = xbmcvfs.File(self.__cookie_, 'w')
                __temp_.close()
            except:
                __temp_ = open(self.__cookie_, 'w')
                __temp_.close()
        self.net = Net(self.__cookie_)
        self.db_table = 'core_0_0_1'
        self.db_file = xbmc.translatePath(os.path.join(self.profile_path, 'database.db'))
        self.db = SQLite(self.db_file)
        if not self.db.execute('CREATE TABLE IF NOT EXISTS ' + self.db_table + ' (sub_site, setting_name UNIQUE, setting)'):
            xbmc.log(self.name + ': Failed to create table <\'' + self.db_table + '\'> in database <\'' + str(self.db) + '\'>', 4)
            raise IOError

    def alert(self, message, title='', image='', time=5000):
        """
        Pop-up notification containing message provided
        :param message: str: message to display in notification
        :param title:   str: title of notification; defaults to self.name
        :param image:   str: path to image location for notification; defaults to self.icon
        :param time:    int: between 1000-10000, defaults to 5000
        """
        if not isinstance(message, str): raise TypeError
        if not title or not isinstance(title, str): title = self.name
        if not image or not isinstance(image, str): image = self.icon
        if not time or not isinstance(time, int): time = 5000
        if 1000 >= time <= 10000: time = 5000
        xbmc.executebuiltin('XBMC.Notification("%s","%s",%d,"%s")' % (title, message, time, image))

    def error(self, message):
        """
        Pop-up error notification containing message provided, log sys.exc_info()[0] if exists, and exit gracefully
        :param message: str: message to display in notification
        """
        if not isinstance(message, str):
            try: message = str(message)
            except: message = self.language('30801')
        title = self.language(30800)
        if sys.exc_info()[0]:
            xbmc.log(self.name + ': ' + str(sys.exc_info()), 4)
            exception = re.search('exceptions\.(.+?)\'>', str(sys.exc_info()[0]))
            if exception: title = exception.group(1)
        if not title: title = self.language('30800')
        self.alert(message, self.name + ' ' + title + ':', self.image('error.png'))
        exit(1)

    def to_bool(self, value):
        """
        Test value against possible False string statements and bool(); returning Boolean True / False
        :param value: value to test against
        :return: Boolean: True / False
        """
        if isinstance(value, str) and bool(value): return not value.lower() in ('false', '0', '0.0', 'n', 'no', 'off')
        else: return bool(value)

    def image(self, image='', failover_image=''):
        """
        :param image: str: image_filename or url
        :return: str: path to image
                  ie. image() returns self.icon
                      image(self.icon) returns self.icon
                      image('error.png') returns translated path '<home_dir>/media/error.png' if exists; self.icon if not
                      image('http://images.com/myimage.jpg') returns 'http://images.com/myimage.jpg'
        """
        if not failover_image: failover_image = self.icon
        if not isinstance(failover_image, str):
            try: failover_image = str(failover_image)
            except: failover_image = self.icon
        if not isinstance(image, str):
            try: image = str(image)
            except: image = failover_image
        if image:
            if image == self.icon: return self.icon
            elif image.startswith('http://'): return image
            elif not image.startswith('http://'):
                image = xbmc.translatePath(os.path.join(self.media_path, image))
                if os.path.isfile(image): return image
        if (failover_image != self.icon) and (not failover_image.startswith('http://')):
            failover_image = xbmc.translatePath(os.path.join(self.media_path, failover_image))
            if not os.path.isfile(failover_image): failover_image = self.icon
        return failover_image

    def art(self, image=''):
        """
        :param image: str: image_filename or url
        :return: str: path to image
                  ie. fanart() returns self.fanart
                      fanart(self.fanart) returns self.fanart
                      fanart('http://images.com/myimage.jpg') returns 'http://images.com/myimage.jpg'
        """
        if not isinstance(image, str):
            try: image = str(image)
            except: return self.fanart
        if image:
            if image == self.fanart: return self.fanart
            elif image.startswith('http://'): return image
        return self.fanart

    def setting(self, setting, value='', write=False):
        """
        Get or Set add-on setting
        :param setting: str: add-on setting id from settings.xml
        :param value:   str: value to change setting to
        :param write:  bool: False - Get setting
                              True - Set setting
        :return: write -  True:     : None
                 write - False:  str: returns string value of setting
        :return: if ''/setting does not exist   : ''
        """
        if not isinstance(setting, str): raise TypeError
        if not isinstance(value, str): raise TypeError
        if not isinstance(write, bool): raise TypeError
        found = xbmcaddon.Addon().getSetting(setting)
        if not found: return ''
        if write:
            if not value: raise SyntaxError
            return xbmcaddon.Addon().setSetting(setting, value)
        return found

    def bool_setting(self, setting, inverse=False):
        """
        Get provided setting and return Boolean result
        :param setting:  str: add-on setting id from settings.xml
        :param inverse: bool: if True will return inverted result
        :return: bool:  True / False
        """
        if not isinstance(setting, str): raise TypeError
        if not isinstance(inverse, bool): raise TypeError
        setting = self.setting(setting)
        if not setting: setting = False
        if inverse:
            return not self.to_bool(setting)
        return self.to_bool(setting)

    def language(self, string_id):
        if isinstance(string_id, str):
            try: string_id = int(string_id)
            except: raise TypeError
        if not isinstance(string_id, int): raise TypeError
        return str(xbmcaddon.Addon().getLocalizedString(string_id))

    def add_items(self, dict_list):
        """
        add_video/music/directory items from a list of dicts
        total_items = len(dict_list)
        required dict items - 'mode':, 'title':, 'cover_url':, 'backdrop_url':
        'contextmenu_items': defaults to []
        'context_replace': defaults to False
        'type': defaults to 3
                0 - video
                1 - music
                2 - picture
                3 - directory
        :param dict_list: [{}]
        :output: add_*item
        """
        if not isinstance(dict_list, list): raise TypeError
        for item in dict_list:
            try: item.keys()
            except: raise TypeError
        for item in dict_list:
            item_type = item.setdefault('type', 3)
            context_items = item.setdefault('contextmenu_items', [])
            context_replace = item.setdefault('context_replace', False)
            total_items = len(dict_list)
            if not isinstance(item_type, int):
                try: item_type = int(item_type)
                except: item_type = 3
            if not isinstance(context_items, list):
                context_items = ast.literal_eval(context_items)
                if not isinstance(context_items, list):
                    context_items = []
            if not isinstance(context_replace, bool):
                context_replace = self.to_bool(context_replace)
            if not isinstance(item, XBMCDict):
                item = XBMCDict(item_type).update(item)
            #
            if item_type == 0:  # video_item
                self.add_video_item(item, item.labels(),
                                    contextmenu_items=context_items, context_replace=context_replace,
                                    fanart=self.art(item['backdrop_url']), img=self.image(item['cover_url']),
                                    total_items=total_items)
            elif item_type == 1:  # music_item
                pass
            elif item_type == 2:  # picture_item
                pass
            elif item_type == 3:  # directory_item
                self.add_directory(item, item.labels(),
                                   contextmenu_items=context_items, context_replace=context_replace,
                                   fanart=self.art(item['backdrop_url']), img=self.image(item['cover_url']),
                                   total_items=total_items)

    def end_of_directory(self, content='', sort_methods=None, default_sort=None):
        """
        :param sort_methods: int:
                                  0 - video
                                  1 - music <not fully implemented/never tested>
                                  2 - picture <not fully implemented/never tested>
                                  3 - directory/files
        """
        if not isinstance(content, str):
            try: content = str(content)
            except: content = ''
        xbmcplugin.setContent(self.handle, content)
        if not isinstance(default_sort, int):
            try: default_sort = int(default_sort)
            except: default_sort = None
        if default_sort is not None:
            try: xbmcplugin.addSortMethod(self.handle, default_sort)
            except: pass
        if sort_methods is not None:
            if not isinstance(sort_methods, int) and sort_methods:
                try: sort_methods = int(sort_methods)
                except: sort_methods = 3
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_UNSORTED)
            if sort_methods == 0:
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_VIDEO_TITLE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_VIDEO_RATING)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_EPISODE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_LASTPLAYED)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_PLAYCOUNT)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_GENRE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_VIDEO_RUNTIME)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_PRODUCTIONCODE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_STUDIO)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_STUDIO_IGNORE_THE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_CHANNEL)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_BITRATE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_COUNTRY)
            elif sort_methods == 1:
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_TRACKNUM)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_DURATION)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_ARTIST_IGNORE_THE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_ARTIST)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_GENRE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_ALBUM)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_ALBUM_IGNORE_THE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_SONG_RATING)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_MPAA_RATING)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_LISTENERS)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_CHANNEL)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_BITRATE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_COUNTRY)
            elif sort_methods == 2:
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_DATE_TAKEN)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_COUNTRY)
            elif sort_methods == 3:
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_DRIVE_TYPE)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_FULLPATH)
                xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_SIZE)
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_FILE)
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_DATEADDED)
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_DATE)
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_TITLE)
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_LABEL)
        else:
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_NONE)
        xbmcplugin.endOfDirectory(self.handle)

    def get_page(self, url):
        if not isinstance(url, str):
            try: url = str(url)
            except: raise TypeError
        try:
            self.net.set_cookies(self.__cookie_)
            content = self.net.http_GET(url, {'Referer': url}).content
            self.net.save_cookies(self.__cookie_)
            soup = BeautifulSoup(self.clean_utf8(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
            return soup.renderContents()
        except (urllib2.HTTPError, urllib2.URLError, httplib.HTTPException, AttributeError, ValueError, Exception),  e:
            self.error(e)
        return ''

    def search_input(self):
        search = xbmcgui.Dialog().input(self.language(30808) + ' ' + self.name)
        search = search.strip()
        if search:
            search = re.sub(r'\s+', ' ', search)
            search = urllib.quote_plus(search)
            return search
        return ''

    def edit_input(self, to_edit=''):
        if not isinstance(to_edit, str):
            try: to_edit = str(to_edit)
            except: to_edit = ''
        edited = xbmcgui.Dialog().input(self.language(30811), to_edit)
        edited = edited.strip()
        if edited:
            search = re.sub(r'\s+', ' ', edited)
            return search
        return ''

    def page_input(self, last_page):
        title = self.language(30810)
        if not isinstance(last_page, int):
            try: last_page = int(last_page)
            except: last_page = 10000
        if last_page != 10000: title = self.language(30809) + ' ' + str(last_page)
        page = xbmcgui.Dialog().numeric(0, title)
        if page:
            if 1 <= int(page) <= last_page: return page
        return ''

    def clean_utf8(self, s):
        """
        Re-encode s to utf-8, try re-encoding any non utf-8 characters against provided alternate 'codecs'
         (latin-1, windows-1252) or drop character if unable to re-encode. return utf-8 encoded result
        :param s: string/unicode to recode to utf-8
        :return: utf-8 encoded s
        """
        if not s: return ''
        elif isinstance(s, unicode): is_unicode = True
        elif not isinstance(s, str):
            is_unicode = False
            try: s = str(s)
            except Exception, e: self.error(e)
        else: is_unicode = False
        encodings = ('latin-1', 'windows-1252')
        output_data = ''
        data = s
        while True:
            try:
                if not data: break
                if is_unicode: data = data.encode('utf-8')
                else: data = unicode(data, 'utf-8')
                output_data += data
                break
            except (UnicodeDecodeError, UnicodeEncodeError), e:
                pos = re.search('position ([0-9]+)-*[0-9]*:', str(e))
                if pos:
                    pos = int(pos.group(1))
                    if is_unicode: output_data += data[:pos].encode('utf-8')
                    else: output_data += unicode(data[:pos], 'utf-8')
                    character = data[pos]
                    data = data[pos+1:]
                else:
                    character = data
                    data = ''
                for enc in encodings:
                    try:
                        if is_unicode: character = unicode(character.encode(enc), enc).encode('utf-8')
                        else: character = unicode(character, enc)
                        output_data += character
                        break
                    except (UnicodeDecodeError, UnicodeEncodeError):
                        if enc == encodings[-1]:
                            break
                        continue
            if not data: break
        try:
            if is_unicode: return output_data
            else: return output_data.encode('utf-8')
        except Exception, e: self.error(e)

    def disclaimer(self, message, title=''):
        if not isinstance(message, str):
            try: message = message.encode('UTF-8')
            except:
                try: message = str(message)
                except: raise TypeError
        if not title: title = self.name
        if not isinstance(title, str):
            try: title = title.encode('UTF-8')
            except:
                try: title = str(title)
                except: title = self.name
        execute = 'SELECT * FROM ' + self.db_table + ' WHERE setting_name=?'
        selected = self.db.fetchall(execute, ('disclaimer', ))
        execute = 'INSERT INTO ' + self.db_table + ' (sub_site, setting_name, setting) VALUES (?, ?, ?)'
        sqlparams = (self.name, 'disclaimer', self.version)
        if selected:
            if selected[0][2] == self.version: return 1
            else:
                execute = 'UPDATE ' + self.db_table + ' SET setting=? WHERE setting_name=? AND sub_site=?'
                sqlparams = (self.version, 'disclaimer', self.name)
                selected = False
        if not selected:
            check = xbmcgui.Dialog().yesno(title, message, nolabel=self.language(30993), yeslabel=self.language(30992))
            if check:
                updated = self.db.execute(execute, sqlparams)
            return check

    def execute(self, execute_this):
        if not isinstance(execute_this, str):
            try: execute_this = execute_this.encode('UTF-8')
            except:
                try: execute_this = str(execute_this)
                except: raise TypeError
        try: xbmc.executebuiltin("XBMC.System.Exec(%s)" % execute_this)
        except: pass

    def developer_home(self):
        return {'mode': '', 'title': self.language(30099), 'url': self.language(30098),
                'site': 'developer_home', 'cover_url': self.image('the_projects.png'),
                'backdrop_url': self.art(), 'type': 3}

    def lock_toggle(self):
        return {'mode': '', 'title': self.language(30721), 'site': 'lock_toggle', 'cover_url': self.image('lock.png'),
                'backdrop_url': self.art(), 'type': 3}

    def menu_separator(self):
        return {'mode': '', 'title': self.language(30999), 'site': 'separator', 'cover_url': self.image(),
                'backdrop_url': self.art(), 'type': 3}

    def change_password(self, database='password.db'):
        if not isinstance(database, str):
            try: database = database.encode('UTF-8')
            except:
                try: database = str(database)
                except: database = 'password.db'
        db_table = 'password_0_0_1'
        db_file = xbmc.translatePath(os.path.join(self.profile_path, database))
        db = SQLite(db_file)
        if not db.execute('CREATE TABLE IF NOT EXISTS ' + db_table + ' (sub_site UNIQUE, password)'):
            xbmc.log(self.name + ': Failed to create table <\'' + db_table + '\'> in database <\'' + str(db) + '\'>', 4)
            raise IOError
        execute = 'SELECT * FROM ' + db_table + ' WHERE sub_site=?'
        oldpassword = db.fetchall(execute, (self.name, ))
        if oldpassword == []:
            newpassword = xbmcgui.Dialog().input(self.language(30813), type=xbmcgui.INPUT_PASSWORD)
            if newpassword:
                execute = 'INSERT INTO ' + db_table + ' (sub_site, password) VALUES (?, ?)'
                sqlparams = (self.name, newpassword)
                updated = db.execute(execute, sqlparams)
                return True
            else: return False
        elif oldpassword:
            oldpassword = oldpassword[0][1]
            temppassword = xbmcgui.Dialog().input(self.language(30812), option=xbmcgui.ALPHANUM_HIDE_INPUT)
            import md5
            checkpassword = md5.new(temppassword).hexdigest()
            if checkpassword == oldpassword:
                newpassword = xbmcgui.Dialog().input(self.language(30813), type=xbmcgui.INPUT_PASSWORD)
                if newpassword:
                    execute = 'UPDATE ' + db_table + ' SET password=? WHERE sub_site=?'
                    sqlparams = (newpassword, self.name)
                    updated = db.execute(execute, sqlparams)
                    return True
                else: return False
            else:
                self.alert(self.language(30910))
                return False
        return False

    def check_password(self, database='password.db'):
        if not isinstance(database, str):
            try: database = database.encode('UTF-8')
            except:
                try: database = str(database)
                except: database = 'password.db'
        db_table = 'password_0_0_1'
        db_file = xbmc.translatePath(os.path.join(self.profile_path, database))
        db = SQLite(db_file)
        if not db.execute('CREATE TABLE IF NOT EXISTS ' + db_table + ' (sub_site UNIQUE, password)'):
            xbmc.log(self.name + ': Failed to create table <\'' + db_table + '\'> in database <\'' + str(db) + '\'>', 4)
            raise IOError
        execute = 'SELECT * FROM ' + db_table + ' WHERE sub_site=?'
        oldpassword = db.fetchall(execute, (self.name, ))
        if oldpassword == []: return True
        elif oldpassword:
            oldpassword = oldpassword[0][1]
            import md5
            checkpassword = md5.new(xbmcgui.Dialog().input(self.language(30814), option=xbmcgui.ALPHANUM_HIDE_INPUT)).hexdigest()
            if checkpassword == oldpassword: return True
            else: return False
        return False

    def toggle_lock(self, database='password.db'):
        if not isinstance(database, str):
            try: database = database.encode('UTF-8')
            except:
                try: database = str(database)
                except: database = 'password.db'
        execute = 'SELECT * FROM ' + self.db_table + ' WHERE setting_name=?'
        selected = self.db.fetchall(execute, ('locked', ))
        if selected:
            execute = 'UPDATE ' + self.db_table + ' SET setting=? WHERE setting_name=? AND sub_site=?'
            if self.to_bool(selected[0][2]):
                can_toggle = self.check_password(database)
                if can_toggle:
                    sqlparams = ('false', 'locked', self.name)
                    updated = self.db.execute(execute, sqlparams)
                    self.alert(self.language(30723))
                    return True
                else:
                    self.alert(self.language(30910))
                    return False
            else:
                sqlparams = ('true', 'locked', self.name)
                if self.has_password(database):
                    updated = self.db.execute(execute, sqlparams)
                    self.alert(self.language(30724))
                    return True
                else:
                    if self.change_password(database):
                        updated = self.db.execute(execute, sqlparams)
                        self.alert(self.language(30724))
                        return True
            return False
        else:
            execute = 'INSERT INTO ' + self.db_table + ' (sub_site, setting_name, setting) VALUES (?, ?, ?)'
            sqlparams = (self.name, 'locked', 'true')
            if self.has_password(database):
                updated = self.db.execute(execute, sqlparams)
                self.alert(self.language(30724))
                return True
            else:
                if self.change_password(database):
                    updated = self.db.execute(execute, sqlparams)
                    self.alert(self.language(30724))
                    return True
            return False

    def is_locked(self):
        execute = 'SELECT * FROM ' + self.db_table + ' WHERE setting_name=?'
        selected = self.db.fetchall(execute, ('locked', ))
        if selected == []: return False
        else: return self.to_bool(selected[0][2])

    def has_password(self, database='password.db'):
        if not isinstance(database, str):
            try: database = database.encode('UTF-8')
            except:
                try: database = str(database)
                except: database = 'password.db'
        db_table = 'password_0_0_1'
        db_file = xbmc.translatePath(os.path.join(self.profile_path, database))
        db = SQLite(db_file)
        if not db.execute('CREATE TABLE IF NOT EXISTS ' + db_table + ' (sub_site UNIQUE, password)'):
            xbmc.log(self.name + ': Failed to create table <\'' + db_table + '\'> in database <\'' + str(db) + '\'>', 4)
            raise IOError
        execute = 'SELECT * FROM ' + db_table + ' WHERE sub_site=?'
        oldpassword = db.fetchall(execute, (self.name, ))
        if oldpassword == []: return False
        else: return True

    def clear_cookies(self):
        try:
            __temp_ = xbmcvfs.File(self.__cookie_, 'w')
            __temp_.close()
            self.alert(self.language(30915))
        except:
            __temp_ = open(self.__cookie_, 'w')
            __temp_.close()
            self.alert(self.language(30915))