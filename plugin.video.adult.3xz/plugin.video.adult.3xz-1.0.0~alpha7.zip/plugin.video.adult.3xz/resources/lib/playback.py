# -*- coding: UTF-8 -*-
"""
    Playback v0.0.1
    - Playback for Personal Kodi Add-ons

    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import os
import sys
import re
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs
from xbmcdict import XBMCDict
import urlresolver
import resolvers

__ADDON_NAME__ = xbmcaddon.Addon().getAddonInfo('name')
__ADDON_ID__ = xbmcaddon.Addon().getAddonInfo('id')
__PROFILE_PATH__ = xbmc.translatePath(os.path.join(xbmc.translatePath('special://profile'), 'addon_data', __ADDON_ID__))
if not xbmcvfs.exists(__PROFILE_PATH__):
    try: xbmcvfs.mkdirs(__PROFILE_PATH__)
    except: os.mkdir(__PROFILE_PATH__)


class Playback():

    def __init__(self):
        self.__profile_path_ = __PROFILE_PATH__
        self.__handle_ = int(sys.argv[1])
        self.__id_ = __ADDON_ID__

    def choose_sources(self, dict_list):
        if not isinstance(dict_list, list): raise TypeError
        for item in dict_list:
            try: item.keys()
            except: raise TypeError
        source_list = []
        chosen = ''
        source = ''
        host = re.compile('(?:http|https)://(?:.+?\.)*?([0-9a-zA-Z_\-]+?)\.[0-9a-zA-Z]{2,}/.*')
        for item in dict_list:
            if item['multi-part']:
                source_host = host.search(item['parts'][0])
                if source_host: source_host = source_host.group(1)
                source_title = source_host + ' - Part 1'
                for index, part in enumerate(item['parts']):
                    source = urlresolver.HostedMediaFile(url=item['parts'][part], title=source_title)
                    source_title = '    - Part ' + str(index + 2)
            else:
                source_host = host.search(item['url'])
                if source_host: source_host = source_host.group(1)
                source_title = source_host
                source = urlresolver.HostedMediaFile(url=item['url'], title=source_title)
            if source: source_list.extend([source])
        if source_list: chosen = urlresolver.choose_source(source_list)
        if chosen:
            stream_url = chosen.resolve()
            if stream_url:
                playback_item = xbmcgui.ListItem(label='', thumbnailImage='')
                playback_item.setPath(stream_url)
                playback_item.setProperty('IsPlayable', 'true')
                playback_item.setProperty('Video', 'true')
                mimetype = re.search('.+?\.(mp4)(?:$|\?|&)', stream_url.lower())
                if mimetype: mimetype = 'mpeg'
                if mimetype: playback_item.setProperty('mimetype', 'video/' + mimetype)
                xbmcplugin.setResolvedUrl(self.__handle_, True, playback_item)