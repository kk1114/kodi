"""
    Playback v0.0.1
    - Playback for Personal Kodi Add-ons

    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import os
import sys
import re
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs
from xbmcdict import XBMCDict
import urlresolver
import playlist
import userporn
import flashx
import googlevideo
import streamin
import videowood
import playvid
import sextvx
import videomega

__ADDON_NAME_ = xbmcaddon.Addon().getAddonInfo('name')
__ADDON_ID_ = xbmcaddon.Addon().getAddonInfo('id')
__PROFILE_PATH__ = xbmc.translatePath(os.path.join(xbmc.translatePath('special://profile'), 'addon_data', __ADDON_ID_))
if not xbmcvfs.exists(__PROFILE_PATH__):
    try: xbmcvfs.mkdirs(__PROFILE_PATH__)
    except: os.mkdir(__PROFILE_PATH__)


class Playback():

    def __init__(self):
        self.__profile_path_ = __PROFILE_PATH__
        self.__pls_file_ = xbmc.translatePath(os.path.join(__PROFILE_PATH__, 'playlist.pls'))
        self.__handle_ = int(sys.argv[1])
        self.__id_ = xbmcaddon.Addon().getAddonInfo('id')

    def choose_sources(self, dict_list):
        if not isinstance(dict_list, list): raise TypeError
        for item in dict_list:
            try: item.keys()
            except: raise TypeError
        source_list = []
        host = re.compile('(?:http|https)://(?:.+?\.)*?([0-9a-zA-Z_\-]+?)\.[0-9a-zA-Z]{2,}/.*')
        resolution = re.compile('.+&resolution=([0-9xX]+?[pPiI])(?:&|$).*')
        for item in dict_list:
            if item['multi-part']:
                source_host = host.search(item['parts'][0])
                source_res = resolution.search(item['parts'][0])
                if source_host: source_host = source_host.group(1)
                else: break
                if source_res: source_res = ' - ' + source_res.group(1)
                else: source_res = ''
                source_title = 'Multi-Part - ' + source_host + source_res
            else:
                source_host = host.search(item['url'])
                source_res = resolution.search(item['url'])
                if source_host: source_host = source_host.group(1)
                else: break
                if source_res: source_res = ' - ' + source_res.group(1)
                else: source_res = ''
                source_title = 'Full - ' + source_host + source_res
            source_url = 'playlist://' + source_host + '/' + str(item['count'])
            source = urlresolver.HostedMediaFile(url=source_url, title=source_title)
            source_list.extend([source])
        if source_list:
            source = urlresolver.choose_source(source_list)
            if source:
                source = next(index for (index, item) in enumerate(dict_list)
                              if item['count'] == int(source.get_media_id()) or item['count'] == source.get_media_id())
                if source or source == 0: self.play(dict_list[int(source)])

    def play(self, source):
        dict_type = source.setdefault('type', 0)
        __xbmcdict_ = XBMCDict(dict_type).update(source)
        src = urlresolver.HostedMediaFile(url=__xbmcdict_['url'])
        if src:
            stream_url = src.resolve()
            if stream_url:
                playback_item = xbmcgui.ListItem(label=__xbmcdict_['title'], thumbnailImage=__xbmcdict_['cover_url'])
                playback_item.setPath(stream_url)
                playback_item.setInfo('video', __xbmcdict_.labels())
                playback_item.setProperty('IsPlayable', 'true')
                playback_item.setProperty('Video', 'true')
                mimetype = re.search('.+?\.([Mm]+[Pp]+4)$', stream_url)
                if mimetype:
                    playback_item.setProperty('mimetype', 'video/' + mimetype.group(1))
                xbmcplugin.setResolvedUrl(self.__handle_, True, playback_item)