# -*- coding: UTF-8 -*-
"""
    3XZ Kodi Add-on
    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import xbmc
import xbmcgui
import xbmcaddon
import os
import sys
import re

from BeautifulSoup import BeautifulSoup, SoupStrainer, Comment

sys.path.append(xbmc.translatePath(os.path.join(xbmc.translatePath('special://home'), 'addons',
                                                xbmcaddon.Addon().getAddonInfo('id'), 'resources', 'lib')))
from core import AddonCore
from xbmcdict import XBMCDict
from playback import Playback

a = AddonCore()
p = Playback()

__params_ = a.queries
__mode_ = __params_['mode']
__site_ = __params_.get('site', 'main')

if __site_ == 'main':
    """
    {'mode': 'main', 'title': 'freeomovie', 'content': '',
     'site': 'freeomovie', 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
    """
    __item_list_ = [{'mode': 'main', 'title': 'Sensual HD', 'content': '',
                     'site': 'sensualhd', 'cover_url': a.image(), 'backdrop_url': a.art(),
                     'type': 3},
                    {'mode': 'main', 'title': 'Watch XXX HD', 'content': '',
                     'site': 'watchxxxhd', 'cover_url': a.image(), 'backdrop_url': a.art(),
                     'type': 3},
                    {'mode': 'main', 'title': 'Xtheatre', 'content': '',
                     'site': 'xtheatre', 'cover_url': a.image(), 'backdrop_url': a.art(),
                     'type': 3},
                    {'mode': 'main', 'title': 'StreamGloud', 'content': '',
                     'site': 'streamgloud', 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                    {'mode': 'main', 'title': 'PlayPorn', 'content': '',
                     'site': 'playporn', 'cover_url': a.image(), 'backdrop_url': a.art(),
                     'type': 3}]
    a.add_items(__item_list_)
    a.end_of_directory()

# !!!!!!!!!!!!!!!!!!! PlayPorn !!!!!!!!!!!!!!!!!!!
elif __site_ == 'playporn':

    __home_url_ = 'http://playporn.to/'
    __search_url_ = __home_url_ + '?submit=Search&s='
    __movies_url_ = __home_url_ + 'category/xxx-movie-stream/'
    __scenes_url_ = __home_url_ + 'category/xxx-scenes-stream/'
    __false_positives_ = ['http://playporn.to/deutsche-milfs-anonym-sex/']

    if __mode_ == 'main':
        __item_list_ = [{'site': __site_, 'mode': 'sub', 'title': a.language(30001), 'content': 'movies',
                         'url': __movies_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                        {'site': __site_, 'mode': 'sub', 'title': a.language(30002), 'content': 'movies',
                         'url': __scenes_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                        {'site': __site_, 'mode': 'list', 'title': a.language(30003), 'content': 'movies',
                         'url': __home_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                        {'site': __site_, 'mode': 'list', 'title': a.language(30004), 'content': 'search',
                         'url': __search_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3}]
        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'sub':
        __item_ = a.language(30006)
        if 'scenes' in __params_['url'].lower(): __item_ = a.language(30007)
        __item_list_ = [{'site': __site_, 'mode': 'category', 'title': a.language(30005), 'content': __params_['content'],
                         'url': __home_url_, 'cover_url': a.image(), 'backdrop_url': a.art(),
                         'type': 3},
                        {'site': __site_, 'mode': 'list', 'title': __item_, 'content': __params_['content'],
                         'url': __params_['url'], 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3}]
        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'category':
        __item_ = 1
        if 'scenes' in __params_['url'].lower(): __item_ = 2
        __html_ = a.get_page(__home_url_)
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('ul', 'nav fl'))
        __item_list_ = []
        for __item_ in __soup_.findAll('ul')[__item_].findAll({'a': True}):
            __item_list_.extend([{'site': 'playporn', 'mode': 'list', 'url': __item_.get('href'), 'content': __params_['content'],
                                  'title': __item_.contents[0].encode('UTF-8'), 'cover_url': a.image(),
                                  'backdrop_url': a.art(), 'type': 3}])
        if __item_list_:
            a.add_items(__item_list_)
            a.end_of_directory()

    elif __mode_ == 'list':
        if __params_['content'] == 'search':
            __item_ = a.search_input()
            if __item_: __params_['url'] = __search_url_ + __item_
            else: exit(1)
        elif __params_['content'] == 'goto':
            __last_item_ = re.search('/page/([0-9]+)/', __params_['url'])
            if __last_item_: __last_item_ = int(__last_item_.group(1))
            else: __last_item_ = 10000
            __item_ = xbmcgui.Dialog().numeric(0, a.language(30891) + ' ' + str(__last_item_))
            if __item_:
                if 1 <= int(__item_) <= __last_item_:
                    __params_['url'] = re.sub('/page/[0-9]+/', '/page/' + str(__item_) + '/', __params_['url'])
            else: exit(1)
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('body'))
        __item_list_ = []
        __params_['mode'] = 'play'
        __params_['content'] = 'movies'
        __params_['type'] = 0
        __params_['duration'] = '120'
        if 'scenes' in __params_['url']: __params_['duration'] = '45'
        __xbmcdict_ = XBMCDict(0).update(__params_)
        for __item_ in __soup_.findAll('div', 'photo-thumb-image'):
            if not __item_.a.get('href') in __false_positives_:
                __dict_ = __xbmcdict_.copy()
                __dict_['url'] = __item_.a.get('href')
                __dict_['title'] = __item_.a.get('title').encode('UTF-8')
                __dict_['tvshowtitle'] = __dict_['title']
                __dict_['originaltitle'] = __dict_['title']
                __dict_['cover_url'] = a.image(__item_.img.get('src'))
                __dict_['thumb_url'] = __dict_['cover_url']
                __dict_['poster'] = __dict_['cover_url']
                __item_list_.extend([__dict_])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', 'more_entries'))
        if __soup_:
            __item_ = __soup_.find('a', 'previouspostslink')
            if __item_: __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'), 'content': __params_['content'],
                                              'title': a.language(30008), 'cover_url': a.image(),
                                              'backdrop_url': a.art(), 'type': 3}])
            __item_ = __soup_.find('a', 'nextpostslink')
            if __item_: __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'), 'content': __params_['content'],
                                              'title': a.language(30009), 'cover_url': a.image(),
                                              'backdrop_url': a.art(), 'type': 3}])
            __item_ = __soup_.find('a', 'last')
            if __item_: __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'), 'content': 'goto',
                                              'title': a.language(30010), 'cover_url': a.image(),
                                              'backdrop_url': a.art(), 'type': 3}])
        if __item_list_:
            a.add_items(__item_list_)
            a.end_of_directory()

    elif __mode_ == 'play':
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'loopedSlider'}))
        __soup_ = __soup_.find(text=lambda text: isinstance(text, Comment))
        if __soup_:
            __soup_ = re.sub('&lt;', '<', __soup_.encode('utf-8'))
            __soup_ = re.sub('&gt;', '>', __soup_)
            __soup_ = BeautifulSoup(__soup_, parseOnlyThese=SoupStrainer('div', 'video'))
            if __soup_:
                __item_list_ = []
                __xbmcdict_ = XBMCDict(0).update(__params_)
                for __index_, __item_ in enumerate(__soup_.findAll('iframe')):
                    __dict_ = __xbmcdict_.copy()
                    __dict_['url'] = __item_.get('src').replace('http://playporn.to/stream/all/?file=', '').encode('UTF-8')
                    if 'flashx.tv' in __dict_['url'].lower():
                        __item_ = re.search('hash=(.+?)&', __dict_['url'])
                        if __item_: __dict_['url'] = 'http://flashx.tv/video/' + __item_.group(1) + '/'
                    elif 'played.to' in __dict_['url'].lower():
                        __item_ = re.search('embed-([a-zA-Z0-9]+?)-.+?html', __dict_['url'])
                        if __item_: __dict_['url'] = 'http://played.to/' + __item_.group(1)
                    __dict_['count'] = __index_
                    __item_list_.extend([__dict_])
                if __item_list_:
                    p.choose_sources(__item_list_)
            else: exit(1)
        else: exit(1)

# !!!!!!!!!!!!!!!!!!! Sensual HD !!!!!!!!!!!!!!!!!!!
elif __site_ == 'sensualhd':
    __home_url_ = 'http://sensualhd.com/'
    __search_url_ = __home_url_ + '?s='
    __false_positives_ = ['http://sensualhd.com/video', 'http://sensualhd.com/video/?order=viewed',
                          'http://sensualhd.com/video/?order=liked', 'http://sensualhd.com/']

    if __mode_ == 'main':
        __item_list_ = [{'site': __site_, 'mode': 'list', 'title': 'All', 'content': 'movies',
                         'url': __home_url_ + 'video/', 'cover_url': a.image(), 'backdrop_url': a.art(),
                         'type': 3},
                        {'site': __site_, 'mode': 'categories', 'title': 'Categories', 'content': 'movies',
                         'url': __home_url_, 'cover_url': a.image(), 'backdrop_url': a.art(),
                         'type': 3},
                        {'site': __site_, 'mode': 'list', 'title': 'Search', 'content': 'search',
                         'url': __search_url_, 'cover_url': a.image(), 'backdrop_url': a.art(),
                         'type': 3}]
        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'categories':
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'navigation-wrapper'}))
        __item_list_ = []
        if __soup_:
            for __item_ in __soup_.findAll('a', {'href': True}):
                if __item_:
                    if __item_.get('href') not in __false_positives_:
                        __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'),
                                              'content': __params_['content'], 'title':__item_.contents[0].encode('UTF-8'),
                                              'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3}])

        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'list':
        if __params_['content'] == 'search':
            __item_ = a.search_input()
            if __item_: __params_['url'] = __search_url_ + __item_
            else: exit(1)
        elif __params_['content'] == 'goto':
            __last_item_ = re.search('/page/([0-9]+)/', __params_['url'])
            if __last_item_: __last_item_ = int(__last_item_.group(1))
            else: __last_item_ = 10000
            __item_ = xbmcgui.Dialog().numeric(0, a.language(30891) + ' ' + str(__last_item_))
            if __item_:
                if 1 <= int(__item_) <= __last_item_:
                    __params_['url'] = re.sub('/page/[0-9]+/', '/page/' + str(__item_) + '/', __params_['url'])
            else: exit(1)
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'class': 'container'}))
        __item_list_ = []
        __params_['mode'] = 'play'
        __params_['content'] = 'movies'
        __params_['type'] = 0
        __params_['duration'] = '25'
        if __soup_:
            __xbmcdict_ = XBMCDict(0).update(__params_)
            for __item_ in __soup_.findAll('div', {'class': re.compile('.*(?:col-xs-6 item|post type-post status-publish).*')}):
                if __item_:
                    if __item_.a.get('href') not in __false_positives_:
                        __dict_ = __xbmcdict_.copy()
                        if __item_.h3:
                            __dict_['url'] = __item_.h3.a.get('href')
                            __dict_['title'] = __item_.h3.a.contents[0].encode('UTF-8')
                        elif __item_.h2:
                            __dict_['url'] = __item_.h2.a.get('href')
                            __dict_['title'] = __item_.h2.a.contents[0].encode('UTF-8')
                        __dict_['tvshowtitle'] = __dict_['title']
                        __dict_['originaltitle'] = __dict_['title']
                        __dict_['cover_url'] = a.image(__item_.img.get('src'))
                        __dict_['thumb_url'] = __dict_['cover_url']
                        __dict_['poster'] = __dict_['cover_url']
                        __item_list_.extend([__dict_])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('ul', {'class': 'pagination'}))
        if __soup_.li:
            __item_ = __soup_.find('a', {'class': 'prev page-numbers'})
            if __item_:
                __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'), 'content': __params_['content'],
                                      'title': a.language(30008), 'cover_url': a.image(),
                                      'backdrop_url': a.art(), 'type': 3}])
            __item_ = __soup_.find('a', {'class': 'next page-numbers'})
            if __item_:
                __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'), 'content': __params_['content'],
                                      'title': a.language(30009), 'cover_url': a.image(),
                                      'backdrop_url': a.art(), 'type': 3}])
                if len(__soup_.findAll('a')) > 2:
                    __last_item_= __soup_.find('a', {'class': 'next page-numbers'}).parent.previousSibling.a.get('href')
                    __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __last_item_, 'content': 'goto',
                                          'title': a.language(30010), 'cover_url': a.image(),
                                          'backdrop_url': a.art(), 'type': 3}])
            else:
                __item_ = __soup_.find('span', {'class': 'page-numbers current'})
                if __item_:
                    if len(__soup_.findAll('a')) > 2:
                        __last_item_ = __soup_.find('span', {'class': 'page-numbers current'}).parent.previousSibling.a.get('href')
                        __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __last_item_, 'content': 'goto',
                                              'title': a.language(30010), 'cover_url': a.image(),
                                              'backdrop_url': a.art(), 'type': 3}])
        else:
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('ul', {'class': 'pager'}))
            __item_ = __soup_.find('li', {'class': 'previous'})
            if __item_:
                __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.previousSibling.get('href'), 'content': __params_['content'],
                                      'title': a.language(30008), 'cover_url': a.image(),
                                      'backdrop_url': a.art(), 'type': 3}])
            __item_ = __soup_.find('li', {'class': 'next'})
            if __item_:
                __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.previousSibling.get('href'), 'content': __params_['content'],
                                      'title': a.language(30009), 'cover_url': a.image(),
                                      'backdrop_url': a.art(), 'type': 3}])
        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'play':
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('object', {'id': re.compile('flashplayer.+')}))
        __item_ = ''
        if __soup_:
            if __soup_.find('param', {'name': 'FlashVars'}):
                __item_ = __soup_.find('param', {'name': 'FlashVars'}).get('value')
                __item_ = re.search('.*?proxy\.link=(.+?)&(?:proxy|skin).*?', __item_)
                if __item_: __item_ = __item_.group(1)
                else: __item_ = ''
        __item_list_ = []
        __xbmcdict_ = XBMCDict(0).update(__params_)
        if 'picasaweb' in __item_:
            __item_id_ = re.search('.*?#(.+?)$', __item_)
            if __item_id_:
                __item_id_ = __item_id_.group(1)
                __html_ = a.get_page(__item_)
                __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('body'))
                if __soup_:
                    __soup_ = re.search('.*?\["shared_group_' + re.escape(__item_id_) + '"\](.+?),"ccOverride":"false"}', __soup_.renderContents(), re.DOTALL)
                    if __soup_:
                        __items_ = re.compile(',{"url":"(https://redirector\.googlevideo\.com/.+?)","height":(.+?),"width":(.+?),"type":"video/.+?"}').findall(__soup_.group(1))
                        if __items_:
                            for __index_, __item_ in enumerate(__items_):
                                if __item_[0]:
                                    __dict_ = __xbmcdict_.copy()
                                    __dict_['url'] = __item_[0].replace('&amp;', '&') + '&resolution=' + __item_[1] + 'p'
                                    __dict_['count'] = __index_
                                    __item_list_.extend([__dict_])
        elif __item_:
            __dict_ = __xbmcdict_.copy()
            __dict_['url'] = __item_
            __dict_['count'] = 1
            __item_list_.extend([__dict_])
        if __item_list_: p.choose_sources(__item_list_)
        else: a.error('No Sources Found')

# !!!!!!!!!!!!!!!!!!! Xtheatre !!!!!!!!!!!!!!!!!!!
elif __site_ == 'xtheatre':
    __home_url_ = 'http://xtheatre.net/'
    __search_url_ = __home_url_ + '?s='
    __false_positives_ = ['http://watchxxxhd.net/watch-full-movies-hd/', 'http://watchxxxhd.net',
                          'http://watchxxxhd.net/category/movies/', 'http://watchxxxhd.net/category/ategorized222/',
                          'http://watchxxxhd.net/watch-full-movies-hd/']

    if __mode_ == 'main':
        __item_list_ = [{'site': __site_, 'mode': 'list', 'title': 'All', 'content': 'movies',
                         'url': __home_url_, 'cover_url': a.image(), 'backdrop_url': a.art(),
                         'type': 3},
                        {'site': __site_, 'mode': 'list', 'title': 'Search', 'content': 'search',
                         'url': __search_url_, 'cover_url': a.image(), 'backdrop_url': a.art(),
                         'type': 3}]
        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'list':
        if __params_['content'] == 'search':
            __item_ = a.search_input()
            if __item_: __params_['url'] = __search_url_ + __item_
            else: exit(1)
        elif __params_['content'] == 'goto':
            __last_item_ = 10000
            __item_ = xbmcgui.Dialog().numeric(0, 'Goto page: ...')
            if __item_:
                if 1 <= int(__item_) <= __last_item_:
                    __params_['url'] = re.sub('/page/[0-9]+/', '/page/' + str(__item_) + '/', __params_['url'])
            else: exit(1)
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'main'}))
        __item_list_ = []
        __params_['mode'] = 'play'
        __params_['content'] = 'movies'
        __params_['type'] = 0
        __params_['duration'] = '120'
        if __soup_:
            __xbmcdict_ = XBMCDict(0).update(__params_)
            for __item_ in __soup_.findAll('div', {'class': 'thumb'}):
                if __item_:
                    if __item_.a.get('href') not in __false_positives_:
                        __dict_ = __xbmcdict_.copy()
                        __dict_['url'] = __item_.a.get('href')
                        __dict_['title'] = __item_.a.get('title').encode('UTF-8')
                        __dict_['tvshowtitle'] = __dict_['title']
                        __dict_['originaltitle'] = __dict_['title']
                        __dict_['cover_url'] = a.image(__item_.img.get('src'))
                        __dict_['thumb_url'] = __dict_['cover_url']
                        __dict_['poster'] = __dict_['cover_url']
                        __item_list_.extend([__dict_])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'class': 'loop-nav-inner'}))
        __last_item_ = False
        if __soup_:
            for __item_ in __soup_.findAll('a', href=True):
                if __item_:
                    if __item_.string.encode('UTF-8') == '« Prev':
                        __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'), 'content': __params_['content'],
                                              'title': a.language(30008), 'cover_url': a.image(),
                                              'backdrop_url': a.art(), 'type': 3}])
                        __last_item_ = __item_.get('href')
                    if __item_.string.encode('UTF-8') == 'Next »':
                        __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'), 'content': __params_['content'],
                                              'title': a.language(30009), 'cover_url': a.image(),
                                              'backdrop_url': a.art(), 'type': 3}])
                        __last_item_ = __item_.get('href')
        if __last_item_:
            __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __last_item_, 'content': 'goto',
                                  'title': a.language(30010), 'cover_url': a.image(),
                                  'backdrop_url': a.art(), 'type': 3}])

        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'play':
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'video'}))
        __item_ = ''
        if __soup_:
            for __script_ in __soup_.findAll('script'):
                if __script_.get('src'):
                    if 'http://videomega.tv/validatehash.php' in __script_['src']:
                        __html_ = a.get_page(__script_['src'])
                        if 'ref=' in __html_:
                            __item_ = 'http://videomega.tv/iframe.php?ref=' + re.compile('.*?ref="(.+?)".*').findall(__html_)[0]
                elif 'ref=' in str(__script_.contents[0]):
                    __temp_ = re.search('.*ref=[\'"](.+?)[\'"]', str(__script_.contents[0]))
                    if __temp_:
                        __item_ = 'http://videomega.tv/iframe.php?ref=' + __temp_.group(1)
            if not __item_ and __soup_.iframe:
                __item_ = __soup_.iframe.get('src').replace('\\', '')
        __item_list_ = []
        __xbmcdict_ = XBMCDict(0).update(__params_)
        if __item_:
            __dict_ = __xbmcdict_.copy()
            __dict_['url'] = __item_
            __dict_['count'] = 1
            __item_list_.extend([__dict_])
        if __item_list_: p.choose_sources(__item_list_)
        else: a.error('No Sources Found')

# !!!!!!!!!!!!!!!!!!! WATCH XXX HD !!!!!!!!!!!!!!!!!!!
elif __site_ == 'watchxxxhd':
    __home_url_ = 'http://watchxxxhd.net/'
    __search_url_ = __home_url_ + '?s='
    __false_positives_ = ['http://watchxxxhd.net/watch-full-movies-hd/', 'http://watchxxxhd.net',
                          'http://watchxxxhd.net/category/movies/', 'http://watchxxxhd.net/category/ategorized222/',
                          'http://watchxxxhd.net/watch-full-movies-hd/']

    if __mode_ == 'main':
        __item_list_ = [{'site': __site_, 'mode': 'list', 'title': 'Recent', 'content': 'movies',
                         'url': __home_url_, 'cover_url': a.image(), 'backdrop_url': a.art(),
                         'type': 3},
                        {'site': __site_, 'mode': 'categories', 'title': 'Categories', 'content': 'movies',
                         'url': __home_url_, 'cover_url': a.image(), 'backdrop_url': a.art(),
                         'type': 3},
                        {'site': __site_, 'mode': 'list', 'title': 'Search', 'content': 'search',
                         'url': __search_url_, 'cover_url': a.image(), 'backdrop_url': a.art(),
                         'type': 3}]
        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'categories':
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'main-nav'}))
        __item_list_ = []
        if __soup_:
            for __item_ in __soup_.findAll('a'):
                if __item_:
                    if __item_.get('href') not in __false_positives_:
                        __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'),
                                              'content': __params_['content'], 'title': __item_.string.encode('UTF-8'),
                                              'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3}])

        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'list':
        if __params_['content'] == 'search':
            __item_ = a.search_input()
            if __item_: __params_['url'] = __search_url_ + __item_
            else: exit(1)
        elif __params_['content'] == 'goto':
            __last_item_ = 10000
            __item_ = xbmcgui.Dialog().numeric(0, 'Goto page: ...')
            if __item_:
                if 1 <= int(__item_) <= __last_item_:
                    __params_['url'] = re.sub('/page/[0-9]+/', '/page/' + str(__item_) + '/', __params_['url'])
            else: exit(1)
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'main'}))
        __item_list_ = []
        __params_['mode'] = 'play'
        __params_['content'] = 'movies'
        __params_['type'] = 0
        __params_['duration'] = '25'
        if __soup_:
            __xbmcdict_ = XBMCDict(0).update(__params_)
            for __item_ in __soup_.findAll('div', {'class': 'thumb'}):
                if __item_:
                    if __item_.a.get('href') not in __false_positives_:
                        __dict_ = __xbmcdict_.copy()
                        __dict_['url'] = __item_.a.get('href')
                        __dict_['title'] = __item_.a.get('title').encode('UTF-8')
                        __dict_['tvshowtitle'] = __dict_['title']
                        __dict_['originaltitle'] = __dict_['title']
                        __dict_['cover_url'] = a.image(__item_.img.get('src'))
                        __dict_['thumb_url'] = __dict_['cover_url']
                        __dict_['poster'] = __dict_['cover_url']
                        __item_list_.extend([__dict_])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'class': 'loop-nav-inner'}))
        __last_item_ = False
        if __soup_:
            for __item_ in __soup_.findAll('a', href=True):
                if __item_:
                    if __item_.string.encode('UTF-8') == '« Prev':
                        __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'), 'content': __params_['content'],
                                              'title': a.language(30008), 'cover_url': a.image(),
                                              'backdrop_url': a.art(), 'type': 3}])
                        __last_item_ = __item_.get('href')
                    if __item_.string.encode('UTF-8') == 'Next »':
                        __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'), 'content': __params_['content'],
                                              'title': a.language(30009), 'cover_url': a.image(),
                                              'backdrop_url': a.art(), 'type': 3}])
                        __last_item_ = __item_.get('href')
        if __last_item_:
            __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __last_item_, 'content': 'goto',
                                  'title': a.language(30010), 'cover_url': a.image(),
                                  'backdrop_url': a.art(), 'type': 3}])

        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'play':
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'video'}))
        __item_ = ''
        if __soup_:
            for __script_ in __soup_.findAll('script'):
                if __script_.get('src'):
                    if 'http://videomega.tv/validatehash.php' in __script_['src']:
                        __html_ = a.get_page(__script_['src'])
                        if 'ref=' in __html_:
                            __item_ = 'http://videomega.tv/iframe.php?ref=' + re.compile('.*?ref="(.+?)".*').findall(__html_)[0]
                elif 'ref=' in str(__script_.contents[0]):
                    __temp_ = re.search('.*ref=[\'"](.+?)[\'"]', str(__script_.contents[0]))
                    if __temp_:
                        __item_ = 'http://videomega.tv/iframe.php?ref=' + __temp_.group(1)
            if not __item_ and __soup_.iframe:
                __item_ = __soup_.iframe.get('src').replace('\\', '')
        __item_list_ = []
        __xbmcdict_ = XBMCDict(0).update(__params_)
        if __item_:
            __dict_ = __xbmcdict_.copy()
            __dict_['url'] = __item_
            __dict_['count'] = 1
            __item_list_.extend([__dict_])
        if __item_list_: p.choose_sources(__item_list_)
        else: a.error('No Sources Found')

# !!!!!!!!!!!!!!!!!!! StreamGloud / QWERTTY !!!!!!!!!!!!!!!!!!!
elif __site_ == 'streamgloud':

    __home_url_ = 'http://qwertty.net'
    __search_url_ = __home_url_ + '/?s='
    __false_positives_ = ['']

    if __mode_ == 'main':
        __item_list_ = [{'site': __site_, 'mode': 'list', 'title': 'All', 'content': 'movies',
                         'url': __home_url_, 'cover_url': a.image(), 'backdrop_url': a.art(),
                         'type': 3},
                        {'site': __site_, 'mode': 'categories', 'title': 'Categories', 'content': 'movies',
                         'url': __home_url_, 'cover_url': a.image(), 'backdrop_url': a.art(),
                         'type': 3}]
        """
        ,
        {'site': __site_, 'mode': 'list', 'title': 'Search', 'content': 'search',
         'url': __search_url_, 'cover_url': a.image(), 'backdrop_url': a.art(),
         'type': 3}
        """
        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'categories':
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'class': 'right-menu'}))
        __item_list_ = []
        if __soup_:
            for __item_ in __soup_.findAll('a'):
                if __item_: __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __home_url_ + __item_.get('href'),
                                                  'content': __params_['content'], 'title': __item_.string.encode('UTF-8'),
                                                  'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3}])
        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'list':
        if __params_['content'] == 'goto':
            __last_item_ = re.search('/page/([0-9]+)/', __params_['url'])
            if __last_item_: __last_item_ = int(__last_item_.group(1))
            else: __last_item_ = 10000
            __item_ = xbmcgui.Dialog().numeric(0, a.language(30891) + ' ' + str(__last_item_))
            if __item_:
                if 1 <= int(__item_) <= __last_item_:
                    __params_['url'] = re.sub('/page/[0-9]+/', '/page/' + str(__item_) + '/', __params_['url'])
            else: exit(1)
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'dle-content'}))
        __item_list_ = []
        __params_['mode'] = 'play'
        __params_['content'] = 'movies'
        __params_['type'] = 0
        __params_['duration'] = '120'
        if __soup_:
            __xbmcdict_ = XBMCDict(0).update(__params_)
            for __item_ in __soup_.findAll('div', {'class': 'main-news'}):
                if __item_:
                    __dict_ = __xbmcdict_.copy()
                    __dict_['url'] = __item_.h2.a.get('href')
                    __dict_['title'] = __item_.h2.a.string.encode('UTF-8')
                    __dict_['tvshowtitle'] = __dict_['title']
                    __dict_['originaltitle'] = __dict_['title']
                    __item_ = __home_url_ + __item_.img.get('src').replace('/thumbs', '')
                    __dict_['cover_url'] = a.image(__item_)
                    __dict_['thumb_url'] = __dict_['cover_url']
                    __dict_['poster'] = __dict_['cover_url']
                    __item_list_.extend([__dict_])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'class': 'navigation'}))
        if __soup_:
            __last_item_ = len(__soup_.findAll('a', href=True)) - 1
            for __index_, __item_ in enumerate(__soup_.findAll('a', href=True)):
                if __item_:
                    if __index_ == 0 and __item_.string.encode('UTF-8') != 'Back': __last_item_ -= 1
                    if __item_.string.encode('UTF-8') == 'Back':
                        __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'), 'content': __params_['content'],
                                              'title': a.language(30008), 'cover_url': a.image(),
                                              'backdrop_url': a.art(), 'type': 3}])
                    if __item_.string.encode('UTF-8') == 'Next':
                        __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'), 'content': __params_['content'],
                                              'title': a.language(30009), 'cover_url': a.image(),
                                              'backdrop_url': a.art(), 'type': 3}])
                    if __index_ == __last_item_:
                        __item_list_.extend([{'site': __site_, 'mode': 'list', 'url': __item_.get('href'), 'content': 'goto',
                                              'title': a.language(30010), 'cover_url': a.image(),
                                              'backdrop_url': a.art(), 'type': 3}])
        a.add_items(__item_list_)
        a.end_of_directory()

    elif __mode_ == 'play':
        __html_ = a.get_page(__params_['url'])
        __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'dle-content'}))
        __item_ = __soup_.find('a')
        __item_list_ = []
        __xbmcdict_ = XBMCDict(0).update(__params_)
        if __item_:
            __dict_ = __xbmcdict_.copy()
            __dict_['url'] = __item_.get('href')
            __dict_['count'] = 1
            __item_list_.extend([__dict_])
            if __item_list_:
                p.choose_sources(__item_list_)
        else: exit(1)