"""
    Favorites v0.0.1
    - Favorites for Personal Kodi Add-ons

    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.


    Required add-on localized strings.xml ids
    <string id="30882">Add</string>
    <string id="30883">Delete</string>
    <string id="30884">All</string>
    <string id="30885">Movies</string>
    <string id="30886">Shows</string>
    <string id="30887">Seasons</string>
    <string id="30888">Episodes</string>
    <string id="30889">Favorites</string>
    <string id="30890">already in favorites</string>
    <string id="30891">Added</string>
    <string id="30892">Removed</string>
    <string id="30893">to favorites</string>
    <string id="30894">from favorites</string>
    <string id="30895">Clear Favorites</string>
    <string id="30896">Are you sure you would like to delete all your favorites?</string>
    <string id="30897">Favorites have been cleared</string>
    <string id="30898">Yes</string>
    <string id="30899">No</string>
"""

# Addon Type, set to addons content type
# 0 - video
# 1 - music
# 2 - picture
__ADDON_TYPE__ = 0
# Filename only, profile path will be added automatically
__FAV_DATABASE_FILE_ = 'database.db'
# Table name to use for favorites in database file
__FAV_MOD_TABLE__ = 'favorites_0_0_1'


import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
from core import AddonCore
from xbmcdict import XBMCDict

a = AddonCore()


__ADDON_NAME__ = xbmcaddon.Addon().getAddonInfo('name')
__ADDON_ID__ = xbmcaddon.Addon().getAddonInfo('id')

try:
    from database import SQLite
except:
    xbmc.log(__ADDON_NAME__ + ': Failed to Import Database Module <\'database.SQLite\'>', 4)
    raise ImportError


__FAV_PROFILE_PATH_ = xbmc.translatePath(os.path.join(xbmc.translatePath('special://profile'),
                                                      'addon_data', __ADDON_ID__))
if not xbmcvfs.exists(__FAV_PROFILE_PATH_):
    try: xbmcvfs.mkdirs(__FAV_PROFILE_PATH_)
    except: os.mkdir(__FAV_PROFILE_PATH_)
__FAV_DATABASE_FILE_ = xbmc.translatePath(os.path.join(__FAV_PROFILE_PATH_, __FAV_DATABASE_FILE_))
__FAV_MOD_DATABASE__ = SQLite(__FAV_DATABASE_FILE_)
if not __FAV_MOD_DATABASE__.execute('CREATE TABLE IF NOT EXISTS ' + __FAV_MOD_TABLE__ + ' (sub_site, content, url UNIQUE, __params_)'):
    xbmc.log(__ADDON_NAME__ + ': Failed to create table <\'' + __FAV_MOD_TABLE__ + '\'> ' +
             'in database <\'' + __FAV_DATABASE_FILE_ + '\'>', 4)
    raise IOError


class ContextMenu():

    def __init__(self):
        self.__site_ = self.__module__

    def add(self, __params_):
        return (__ADDON_NAME__ + ' - ' + a.language(30882) + ' ' + a.language(30893),
                'XBMC.RunPlugin(%s)' % a.build_plugin_url({'site': self.__site_, 'mode': 'add_favorite', '__params_': __params_}))

    def delete(self, __params_):
        return (__ADDON_NAME__ + ' - ' + a.language(30883) + ' ' + a.language(30894),
                'XBMC.RunPlugin(%s)' % a.build_plugin_url({'site': self.__site_, 'mode': 'delete_favorite', '__params_': __params_}))

    def clear(self, sub_site=''):
        return (__ADDON_NAME__ + ' - ' + a.language(30895),
                'XBMC.RunPlugin(%s)' % a.build_plugin_url({'site': self.__site_, 'mode': 'clear_favorites', 'sub_site': sub_site}))


class Site():

    def __init__(self, __params_):
        __site_ = self.__module__
        self.__addon_id_ = __ADDON_ID__
        self.__addon_name_ = __ADDON_NAME__
        self.__addon_icon_ = xbmc.translatePath(os.path.join(xbmc.translatePath('special://home'),
                                                             'addons', self.__addon_id_, 'icon.png'))        
        self.__language_ = xbmcaddon.Addon().getLocalizedString
        self.__database_ = __FAV_MOD_DATABASE__
        self.__table_ = __FAV_MOD_TABLE__        
        __mode_ = __params_['mode']

        if __mode_ == 'main':
            __item_list_ = [{'site': __site_, 'mode': 'list_favorites', 'title': a.language(30884), 'content': 'all',
                             'sub_site': __params_['sub_site'], 'cover_url': a.image(), 'backdrop_url': a.art(),
                             'contextmenu_items': [ContextMenu().clear(__params_['sub_site'])], 'type': 3},
                            {'site': __site_, 'mode': 'list_favorites', 'title': a.language(30885), 'content': 'movies',
                             'sub_site': __params_['sub_site'], 'cover_url': a.image(), 'backdrop_url': a.art(),
                             'contextmenu_items': [ContextMenu().clear(__params_['sub_site'])], 'type': 3},
                            {'site': __site_, 'mode': 'list_favorites', 'title': a.language(30888), 'content': 'episodes',
                             'sub_site': __params_['sub_site'], 'cover_url': a.image(), 'backdrop_url': a.art(),
                             'contextmenu_items': [ContextMenu().clear(__params_['sub_site'])], 'type': 3}]

            a.add_items(__item_list_)
            a.end_of_directory()

        elif __mode_ == 'add_favorite':
            __params_ = XBMCDict(__ADDON_TYPE__).str_update(__params_['__params_'])
            execute = 'INSERT INTO ' + self.__table_ + ' (sub_site, content, url, __params_) VALUES (?, ?, ?, ?)'
            inserted = self.__database_.execute(execute, (__params_['sub_site'], __params_['content'], __params_['url'], str(__params_)))
            if self.__bool_(inserted):
                if inserted == 1:
                    self.__alert_(str(self.__language_(30891) + ' ' + __params_['title'].decode('ascii', 'ignore') + ' ' + self.__language_(30893)))
                if inserted == 2:
                    self.__alert_(str(__params_['title'].decode('ascii', 'ignore') + ' ' + self.__language_(30890)))

        elif __mode_ == 'delete_favorite':
            __params_ = XBMCDict(__ADDON_TYPE__).str_update(__params_['__params_'])
            execute = 'DELETE FROM ' + self.__table_ + ' WHERE sub_site=? AND content=? AND url=?'
            deleted = self.__database_.execute(execute, (__params_['sub_site'], __params_['content'], __params_['url']))
            if self.__bool_(deleted):
                self.__alert_(str(self.__language_(30892) + ' ' + __params_['title'].decode('ascii', 'ignore') + ' ' + self.__language_(30894)))
                xbmc.executebuiltin('Container.Refresh')

        elif __mode_ == 'list_favorites':
            if __params_['content'] == 'all':
                sql_params = (__params_['sub_site'],)
                execute = 'SELECT * FROM ' + self.__table_ + ' WHERE sub_site=?'
            else:
                sql_params = (__params_['sub_site'], __params_['content'])
                execute = 'SELECT * FROM ' + self.__table_ + ' WHERE sub_site=? AND content=?'
            selected = self.__database_.fetchall(execute, sql_params)
            item_list = []
            if selected:
                for site, content, url, params in selected:
                    __params_ = XBMCDict(__ADDON_TYPE__).str_update(params)
                    __params_['contextmenu_items'] = [ContextMenu().delete(__params_), ContextMenu().clear(__params_['sub_site'])]
                    item_list.extend([__params_])
            if item_list:
                a.add_items(item_list)
            a.end_of_directory()

        elif __mode_ == 'clear_favorites':
            """
            Prompt user for confirmation prior to clearing all favorites / removing favorites table
            """
            if not __params_['sub_site']:
                execute = 'DROP TABLE ' + self.__table_
                sql_params = ''
            else:
                execute = 'DELETE FROM ' + self.__table_ + ' WHERE sub_site=?'
                sql_params = (__params_['sub_site'],)
            clear_favs = xbmcgui.Dialog().yesno(
                self.__addon_name_ + ' - ' + self.__language_(30895), ' ', self.__language_(30896),
                nolabel=self.__language_(30899), yeslabel=self.__language_(30898))
            if self.__bool_(clear_favs):
                cleared = self.__database_.execute(execute, sql_params)
                if self.__bool_(cleared):
                    self.__alert_(str(self.__language_(30897)))
                    xbmc.executebuiltin('Container.Refresh')

    def __alert_(self, message):
        """
        Pop-up notification containing message provided
        :param message: str: message to display in notification
        """
        if not isinstance(message, str):
            message = 'message expected <type \'str\'>, got ' + str(type(message))
        title = self.__addon_name_ + ' ' + self.__language_(30889)
        xbmc.executebuiltin('XBMC.Notification("%s","%s",%d,"%s")' % (title, message, 5000, self.__addon_icon_))

    def __bool_(self, value):
        """
        Test value against possible False string statements and bool(); returning Boolean True / False
        :param value: value to test against
        :return: Boolean: True / False
        """
        if isinstance(value, str) and bool(value): return not value.lower() in ('false', '0', '0.0', 'n', 'no', 'off')
        else: return bool(value)
