"""
    Kodi urlresolver plugin
    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re, urllib, urllib2, os
from t0mm0.common.net import Net
from urlresolver import common
from urlresolver.plugnplay.interfaces import UrlResolver
from urlresolver.plugnplay.interfaces import PluginSettings
from urlresolver.plugnplay import Plugin


error_logo = os.path.join(common.addon_path, 'resources', 'images', 'redx.png')


class AAAVideomegaResolver(Plugin, UrlResolver, PluginSettings):
    implements = [UrlResolver, PluginSettings]
    name = "3xzvideomega"
    domains = ["videomega.tv"]

    def __init__(self):
        p = self.get_setting('priority') or 100
        self.priority = int(p)
        self.net = Net()
        self.headers = {'Referer': 'http://videomega.tv/'}

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)
        stream_url = None
        try:
            self.headers['Referer'] = web_url
            resp = self.net.http_GET(web_url, headers=self.headers)
            html = resp.content
            if 'Error connecting to db' in html: return self.unresolvable(0, 'Error connecting to DB')
            r = re.compile('document.write.unescape."(.+?)"').findall(html)
            if r:
                unescaped_str = urllib.unquote(r[-1])
                r = re.search('file *: *"(.*?)"', unescaped_str)
                if r:
                    stream_url = r.group(1)
                    stream_url = stream_url.replace(" ", "%20")
            if stream_url: return stream_url
            else: raise Exception('No playable video found.')
            
        except urllib2.URLError, e:
            common.addon.log_error('Videomega: got http error %d fetching %s' % (e.reason, web_url))
            common.addon.show_small_popup(title='[B][COLOR white]Videomega[/COLOR][/B]', msg='[COLOR red]HTTP Error: %s[/COLOR]' % e, delay=5000, image=error_logo)
        except Exception, e:
            common.addon.log_error('**** Videomega Error occured: %s' % e)
            common.addon.show_small_popup(title='[B][COLOR white]Videomega[/COLOR][/B]', msg='[COLOR red]%s[/COLOR]' % e, delay=5000, image=error_logo)

    def get_url(self, host, media_id):
        if len(media_id) == 60:
            try:
                html = self.net.http_GET('http://%s/validatehash.php?hashkey=%s' % (host, media_id), headers=self.headers).content
                if 'Error connecting to db' in html: return self.unresolvable(0, 'Error connecting to DB')
                if 'ref=' in html:
                    return 'http://%s/cdn.php?ref=%s' % (host, re.compile('.*?ref="(.+?)".*').findall(html)[0])
                else: raise Exception('No playable video found.')
            except urllib2.URLError, e:
                common.addon.log_error('Videomega: got http error %d fetching %s' % (e.reason, 'http://%s/validatehash.php?hashkey=%s' % (host, media_id)))
                common.addon.show_small_popup(title='[B][COLOR white]Videomega[/COLOR][/B]', msg='[COLOR red]HTTP Error: %s[/COLOR]' % e, delay=5000, image=error_logo)
            except Exception, e:
                common.addon.log_error('**** Videomega Error occured: %s' % e)
                common.addon.show_small_popup(title='[B][COLOR white]Videomega[/COLOR][/B]', msg='[COLOR red]%s[/COLOR]' % e, delay=5000, image=error_logo)
        else:
            return 'http://%s/iframe.php?ref=%s' % (host, media_id)

    def get_host_and_id(self, url):
        r = re.search('//((?:www.)?(?:.+?))/.*(?:\?(?:ref|hashkey)=)([0-9a-zA-Z]+)', url)
        if r: return r.groups()
        else: return False

    def valid_url(self, url, host):
        if self.get_setting('enabled') == 'false': return False
        return re.match('http://(?:www.)?videomega.tv/(?:iframe|cdn|validatehash|\?ref=).(?:php|js|.*)\?*', url) or 'videomega' in host
