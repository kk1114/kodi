# -*- coding: UTF-8 -*-
"""
     Add-on Base v0.0.1
    - Dynamically load site modules from lib\sites for Personal Kodi Add-ons

    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import sys
import re
import xbmc
import xbmcaddon

sys.path.append(xbmc.translatePath(os.path.join(xbmc.translatePath('special://home'), 'addons',
                                                xbmcaddon.Addon().getAddonInfo('id'), 'resources', 'lib')))
__sitepath__ = xbmc.translatePath(os.path.join(xbmc.translatePath('special://home'), 'addons',
                                  xbmcaddon.Addon().getAddonInfo('id'), 'resources', 'lib', 'sites'))
sys.path.append(__sitepath__)

from core import AddonCore

a = AddonCore()
__params__ = a.queries
__param__ = __params__.get('site', 'main')

if __param__ == 'main':

    __sites__ = []
    __item_list__ = []
    __site_list__ = []

    for __file__ in os.listdir(__sitepath__):
        if os.path.isfile(os.path.join(__sitepath__, __file__)):
            __site__ = re.search('^([a-zA-Z0-9]+[a-zA-Z0-9_\-]+)\.py$', __file__)
            if __site__:
                __sites__.extend([__site__.groups()[0]])
    if __sites__:
        if len(__sites__) == 1:
            try:
                i = __import__(__sites__[0], fromlist=[''])
                i.Site(__params__)
            except ImportError: a.error(str(a.language(30907) + ' ' + a.name))
        elif len(__sites__) > 1:
            for __site__ in __sites__:
                try:
                    i = __import__(__site__, fromlist=[''])
                    if i:
                        order = 999
                        try:
                            if i.order:
                                if not isinstance(i.order, int):
                                    try: order = int(i.order)
                                    except: order = 999
                                else: order = i.order
                        except: pass
                        __item_list__.append((order, {'mode': 'main', 'title': i.title, 'content': '',
                                                      'site': __site__, 'cover_url': a.image(i.image),
                                                      'backdrop_url': a.art(i.art), 'type': 3}))
                except: pass
            if __item_list__:
                __item_list__ = sorted(__item_list__, key=lambda __item__: __item__[0])
                for __item__ in __item_list__:
                    __site_list__.extend([__item__[1]])
            if __site_list__:
                a.add_items(__site_list__)
                a.end_of_directory()
            else: a.error(str(a.language(30907) + ' ' + a.name))
else:
    try:
        i = __import__(__param__, fromlist=[''])
        i.Site(__params__)
    except ImportError: a.error(str(a.language(30907) + ' ' + __param__))
