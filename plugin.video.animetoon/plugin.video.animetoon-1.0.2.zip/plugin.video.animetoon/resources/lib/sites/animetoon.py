# -*- coding: UTF-8 -*-
"""
    Copyright (C) 2014  smokdpi

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


""" Site information used for main menu if more than 1 site """
title = 'AnimeToon'
image = ''
art = ''
order = 1


class Site():

    def __init__(self, __params_):
        import re
        import time
        from datetime import datetime
        from core import AddonCore
        from xbmcdict import XBMCDict
        from BeautifulSoup import BeautifulSoup, SoupStrainer, Comment
        from favorites import ContextMenu as Fc

        a = AddonCore()
        __site_ = self.__module__
        __mode_ = __params_['mode']

        __home_url_ = 'http://animetoon.tv/'
        __popular_series_url_ = __home_url_ + 'popular-list/'
        __random_url_ = __home_url_ + 'toon-random/'
        __search_url_ = __home_url_ + 'toon/search?key='
        __dubbed_anime_url_ = 'dubbed-anime'
        __cartoons_url_ = 'cartoon'
        __movies_url_ = 'movies'

        if __mode_ == 'main':
            __item_list_ = [{'site': __site_, 'mode': 'sub', 'title': a.language(30001), 'content': 'tvshows',
                            'url': __dubbed_anime_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'sub', 'title': a.language(30002), 'content': 'tvshows',
                            'url': __cartoons_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'sub', 'title': a.language(30003), 'content': 'movies',
                            'url': __movies_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'list_series', 'title': a.language(30004), 'content': 'tvshows',
                            'url': __popular_series_url_, 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'list_episodes', 'title': a.language(30006), 'url': __random_url_,
                            'content': 'tvshows', 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'list_series', 'title': a.language(30015), 'url': __search_url_,
                            'content': 'search', 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3},
                            {'site': 'favorites', 'sub_site': __site_, 'title': a.language(30889),
                             'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3}]
            a.add_items(__item_list_)
            a.end_of_directory()

        elif __mode_ == 'sub':
            __item_list_ = [{'site': __site_, 'mode': 'list_index', 'url': __home_url_ + __params_['url'] + '/',
                             'content': __params_['content'], 'title': a.language(30008), 'cover_url': a.image(),
                             'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'az', 'url': __home_url_ + 'alpha-' + __params_['url'] + '/',
                             'content': __params_['content'], 'title': a.language(30007), 'cover_url': a.image(),
                             'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'genres', 'url': __home_url_ + re.sub('movies', 'movie', __params_['url']) + '-genres/',
                             'content': __params_['content'], 'title': a.language(30009), 'cover_url': a.image(),
                             'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'list_series', 'url': __home_url_ + 'popular-' + __params_['url'] + '/',
                             'content': __params_['content'], 'title': a.language(30010), 'cover_url': a.image(),
                             'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'list_series', 'url': __home_url_ + 'new-' + __params_['url'] + '/',
                             'content': __params_['content'], 'title': a.language(30011), 'cover_url': a.image(),
                             'backdrop_url': a.art(), 'type': 3},
                            {'site': __site_, 'mode': 'list_series', 'url': __home_url_ + 'recent-' + __params_['url'] + '/',
                             'content': __params_['content'], 'title': a.language(30012), 'cover_url': a.image(),
                             'backdrop_url': a.art(), 'type': 3}]
            if __params_['url'] != 'movies':
                __item_list_.extend([{'site': __site_, 'mode': 'list_series', 'url': __home_url_ + 'ongoing-' + __params_['url'] + '/',
                                      'content': __params_['content'], 'title': a.language(30013), 'cover_url': a.image(),
                                      'backdrop_url': a.art(), 'type': 3},
                                    {'site': __site_, 'mode': 'list_series', 'url': __home_url_ + 'completed-' + __params_['url'] + '/',
                                     'content': __params_['content'], 'title': a.language(30014), 'cover_url': a.image(),
                                     'backdrop_url': a.art(), 'type': 3}])
            a.add_items(__item_list_)
            a.end_of_directory()

        elif __mode_ == 'az':
            import string
            __items_ = string.ascii_lowercase
            __item_list_ = [{'site': __site_, 'mode': 'list_series', 'url': __params_['url'] + 'others/', 'content': __params_['content'],
                             'title': '#', 'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3}]
            for __item_ in __items_:
                __item_list_.extend([{'site': __site_, 'mode': 'list_series', 'url': __params_['url'] + __item_ + '/',
                                      'content': __params_['content'], 'title': __item_.upper(), 'cover_url': a.image(),
                                      'backdrop_url': a.art(), 'type': 3}])
            a.add_items(__item_list_)
            a.end_of_directory()

        elif __mode_ == 'genres':
            __html_ = a.get_page(__params_['url'])
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('table', id='listing'),
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)
            __items_ = __soup_.findAll('td', text=re.compile('[0-9+]'))
            __item_list_ = []
            for __index_, __item_ in enumerate(__soup_.findAll({'a': True})):
                try: __count_ = int(__items_[__index_])
                except: __count_ = 0
                if __count_ > 3:
                    __item_list_.extend([{'site': __site_, 'mode': 'list_series', 'url': __item_.get('href'), 'content': __params_['content'],
                                          'title': __item_.contents[0].encode('UTF-8') + ' (' + str(__count_) + ')',
                                          'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3}])
            if __item_list_:
                a.add_items(__item_list_)
                a.end_of_directory()

        elif __mode_ == 'list_index':
            __html_ = a.get_page(__params_['url'])
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('table', 'series_index'),
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)
            __item_list_ = []
            __xbmcdict_ = XBMCDict().update(__params_)
            for __index_, __item_ in enumerate(__soup_.findAll({'a': True})):
                __dict_ = __xbmcdict_.copy()
                __dict_['mode'] = 'list_episodes'
                __dict_['title'] = __item_.contents[0].encode('UTF-8')
                __dict_['url'] = __item_.get('href')
                __dict_['sub_site'] = __site_
                __dict_['contextmenu_items'] = [Fc().add(__dict_)]
                __item_list_.extend([__dict_])
            if __item_list_:
                a.add_items(__item_list_)
                a.end_of_directory(__xbmcdict_['content'], __xbmcdict_.media_type(), 10)

        elif __mode_ == 'list_series':
            if __params_['content'] == 'search':
                __params_['content'] = 'tvshows'
                __item_ = a.search_input()
                if __item_: __params_['url'] = __search_url_ + __item_
                else: exit(1)
            __html_ = a.get_page(__params_['url'])
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', 'series_list'),
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)
            __item_list_ = []
            __xbmcdict_ = XBMCDict().update(__params_)
            for __li_ in __soup_.findAll({'li': True}):
                if __li_.h3.a.get('href'):
                    __dict_ = __xbmcdict_.copy()
                    __dict_['title'] = __li_.h3.a.contents[0].encode('UTF-8').strip()
                    __dict_['tvshowtitle'] = __li_.h3.a.contents[0].encode('UTF-8').strip()
                    __dict_['originaltitle'] = __li_.h3.a.contents[0].encode('UTF-8').strip()
                    __dict_['mode'] = 'list_episodes'
                    __item_ = __li_.find('span', 'type_indic').contents[0].encode('UTF-8').strip()
                    if 'movie' in __item_.lower() or re.match('.*movie[^s].*', __dict_['title'].lower()):
                        __dict_['content'] = 'movies'
                        __dict_['duration'] = '75'
                        __dict_['type'] = 0
                        __dict_['mode'] = 'play'
                    elif 'movie' in __dict_['title'].lower():
                        __dict_['content'] = 'movies'
                    elif re.match('.*season\s*[0-9]+.*', __dict_['title'].lower()):
                        __dict_['season'] = int(re.search('season\s*([0-9]+)', __dict_['title'].lower()).group(1))
                    __dict_['url'] = __li_.h3.a.get('href')
                    __dict_['cover_url'] = re.sub(r'/small/', '/big/', __li_.img.get('src'))
                    __xbmcdict_['thumb_url'] = __xbmcdict_['cover_url']
                    __xbmcdict_['banner_url'] = __xbmcdict_['cover_url']
                    __xbmcdict_['poster'] = __xbmcdict_['cover_url']
                    __item_ = re.search('\s*(.+?)\s+\[', __li_.find('div', 'descr').contents[0].encode('UTF-8').strip())
                    if __item_:
                        __dict_['plotoutline'] = __item_.group(1)
                        __dict_['plot'] = __item_.group(1)
                    __items_ = __li_.findAll('span', 'bold')
                    __dict_['status'] = __items_[0].contents[0].encode('UTF-8').strip()
                    try: __dict_['year'] = int(__items_[1].contents[0].encode('UTF-8').strip())
                    except: pass
                    __item_ = re.search('^(?:([0-9\.]+)|na)(?:/10)*\s+\(([0-9]+)\s+votes\s*\)$',
                                        __items_[2].contents[0].encode('UTF-8').strip().lower())
                    if __item_:
                        try: __dict_['rating'] = float(__item_.group(1))
                        except: pass
                        __dict_['votes'] = __item_.group(2) + ' votes'
                    __dict_['sub_site'] = __site_
                    __dict_['contextmenu_items'] = [Fc().add(__dict_)]
                    __item_list_.extend([__dict_])
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('ul', 'pagination'))
            __item_ = __soup_.find('a', text='Prev')
            if __item_:
                __item_list_.extend([{'site': __site_, 'mode': 'list_series', 'url': __item_.parent.get('href'),
                                      'content': __params_['content'], 'title': '  ' + a.language(30017),
                                      'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3}])
            __item_ = __soup_.find('a', text='Next')
            if __item_:
                __item_list_.extend([{'site': __site_, 'mode': 'list_series', 'url': __item_.parent.get('href'),
                                      'content': __params_['content'], 'title': '  ' + a.language(30018),
                                      'cover_url': a.image(), 'backdrop_url': a.art(), 'type': 3}])
            if __item_list_:
                a.add_items(__item_list_)
                a.end_of_directory(__xbmcdict_['content'], __xbmcdict_.media_type())

        elif __mode_ == 'list_episodes':
            __html_ = a.get_page(__params_['url'])
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'series_info'}),
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)
            __item_ = __soup_.find('span', text='Category:').findNext('a').contents[0].encode('UTF-8').strip()
            if 'movie' in __item_.lower() or 'movie' in __params_['title'].lower():
                __params_['content'] = 'movies'
                __params_['duration'] = '75'
            else: __params_['content'] = 'episodes'
            __params_['type'] = 0
            __item_list_ = []
            __xbmcdict_ = XBMCDict().update(__params_)
            __xbmcdict_['mode'] = 'play'
            __xbmcdict_['cover_url'] = __soup_.find('img').get('src')
            __xbmcdict_['thumb_url'] = __xbmcdict_['cover_url']
            __xbmcdict_['banner_url'] = __xbmcdict_['cover_url']
            __xbmcdict_['poster'] = __xbmcdict_['cover_url']
            __xbmcdict_['tvshowtitle'] = __soup_.find('h1').contents[0].encode('UTF-8').strip()
            __xbmcdict_['originaltitle'] = __soup_.find('h1').contents[0].encode('UTF-8').strip()
            __xbmcdict_['status'] = __soup_.find('span', text='Status:').next.strip()
            try: __xbmcdict_['year'] = int(__soup_.find('span', text='Released:').next.strip())
            except: pass
            try: __xbmcdict_['rating'] = float(__soup_.find('span', {'id': 'rating_num'}).contents[0].encode('UTF-8').strip())
            except: pass
            __xbmcdict_['votes'] = __soup_.find('span', {'id': 'votes'}).contents[0].encode('UTF-8').strip() + ' votes'
            __item_ = __soup_.find('span', {'id': 'brief_notes'})
            if __item_:
                __xbmcdict_['plotoutline'] = __soup_.find('span', {'id': 'brief_notes'}).contents[0].encode('UTF-8').strip()
                __xbmcdict_['plot'] = __soup_.find('span', {'id': 'full_notes'}).contents[0].encode('UTF-8').strip()
            else:
                __xbmcdict_['plotoutline'] = __soup_.find('span', text='Description:').findNext('div').contents[0].encode('UTF-8').strip()
                __xbmcdict_['plot'] = __soup_.find('span', text='Description:').findNext('div').contents[0].encode('UTF-8').strip()
            __xbmcdict_['genre'] = ', '.join([__item_.contents[0].encode('UTF-8')
                                              for __item_ in __soup_.find('span', text='Genres:').findAllNext('a')])
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'videos'}),
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)
            __items_ = __soup_.findAll('span', 'right_text')
            for __index_, __item_ in enumerate(__soup_.findAll('a', {'href': True})):
                __dict_ = __xbmcdict_.copy()
                __dict_['title'] = __item_.contents[0].encode('UTF-8').strip()
                __dict_['url'] = __item_.get('href')
                __item_ = __items_[__index_].contents[0].encode('UTF-8').strip()
                __dict_['date'] = datetime(*(time.strptime(__item_, '%b %d, %Y')[0:6])).strftime("%d.%m.%Y")
                if re.match('.*episode\s*[0-9]+.*', __dict_['title'].lower()):
                    __dict_['episode'] = int(re.search('episode\s*([0-9]+)', __dict_['title'].lower()).group(1))
                    if re.match('.*season\s*[0-9]+.*', __dict_['title'].lower()):
                        __dict_['season'] = int(re.search('season\s*([0-9]+)', __dict_['title'].lower()).group(1))
                    try:
                        if int(__dict_['season']) == 0: __dict_['season'] = 1
                    except: pass
                __dict_['sub_site'] = __site_
                __dict_['contextmenu_items'] = [Fc().add(__dict_)]
                __item_list_.extend([__dict_])
            while True:
                __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('ul', 'pagination'))
                __item_ = __soup_.find('a', text='Next')
                if not __item_:
                    break
                __html_ = a.get_page(__item_.parent.get('href'))
                __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'videos'}),
                                        convertEntities=BeautifulSoup.HTML_ENTITIES)
                for __index_, __item_ in enumerate(__soup_.findAll('a', {'href': True})):
                    __dict_ = __xbmcdict_.copy()
                    __dict_['title'] = __item_.contents[0].encode('UTF-8').strip()
                    __dict_['url'] = __item_.get('href')
                    __item_ = __items_[__index_].contents[0].encode('UTF-8').strip()
                    __dict_['date'] = datetime(*(time.strptime(__item_, '%b %d, %Y')[0:6])).strftime("%d.%m.%Y")
                    if re.match('.*episode\s*[0-9]+.*', __dict_['title'].lower()):
                        __dict_['episode'] = int(re.search('episode\s*([0-9]+)', __dict_['title'].lower()).group(1))
                        if re.match('.*season\s*[0-9]+.*', __dict_['title'].lower()):
                            __dict_['season'] = int(re.search('season\s*([0-9]+)', __dict_['title'].lower()).group(1))
                        try:
                            if int(__dict_['season']) == 0: __dict_['season'] = 1
                        except: pass
                    __dict_['sub_site'] = __site_
                    __dict_['contextmenu_items'] = [Fc().add(__dict_)]
                    __item_list_.extend([__dict_])
            if __item_list_:
                a.add_items(__item_list_)
                a.end_of_directory(__xbmcdict_['content'], __xbmcdict_.media_type(), 10)

        elif __mode_ == 'play':
            __html_ = a.get_page(__params_['url'])
            if __params_['content'] == 'movies':
                __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'videos'}),
                                        convertEntities=BeautifulSoup.HTML_ENTITIES)
                __item_ = __soup_.find('a', {'href': True})
                if __item_: __params_['url'] = __item_.get('href')
            __html_ = a.get_page(__params_['url'])
            __soup_ = BeautifulSoup(__html_, parseOnlyThese=SoupStrainer('div', {'id': 'streams'}),
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)
            __item_list_ = []
            __xbmcdict_ = XBMCDict().update(__params_)
            for __items_ in __soup_.findAll('div', 'vmargin'):
                __dict_ = __xbmcdict_.copy()
                __item_ = __items_.find('iframe')
                if __items_.find('ul', 'part_list'):
                    __dict_['multi-part'] = True
                    __dict_['parts'] = []
                    __dict_['url'] = ''
                    for __index_, __items_ in enumerate(__items_.ul.findAll('li')):
                        __compile_ = re.compile(r'(part.*?)[1-9]', re.IGNORECASE)
                        __dict_['parts'].extend([__compile_.sub('\g<01>' + str(__index_ + 1), __item_.get('src')).encode('UTF-8')])
                    __item_list_.extend([__dict_])
                else:
                    __dict_['url'] = __item_.get('src')
                    __item_list_.extend([__dict_])
            if __item_list_:
                from playback import Playback
                Playback().choose_sources(__item_list_)
            else: a.error(a.language(30904))